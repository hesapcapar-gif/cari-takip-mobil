import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'login_screen.dart';
import 'customer_detail_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;
  bool _hideAmounts = false;
  Map<String, dynamic> _dash = {};
  List<dynamic> _customers = [];
  List<dynamic> _dueItems = [];
  String _search = '';

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    try {
      final d = await ApiService.getDashboard();
      final c = await ApiService.getCustomers(_search);
      final due = await ApiService.getDueTracking();
      if (!mounted) return;
      setState(() {
        _dash = d;
        _customers = c;
        _dueItems = due;
      });
    } catch (_) {}
  }

  String _money(dynamic val) {
    if (_hideAmounts) return '••••• ₺';
    final num v = (val is num) ? val : double.tryParse(val.toString()) ?? 0;
    return '${v.toStringAsFixed(2)} ₺';
  }

  void _openAddCustomerDialog() {
    final nameCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    String type = 'musteri';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 20,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Yeni Cari Ekle', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Cari Ünvan / Ad Soyad', border: OutlineInputBorder())),
            const SizedBox(height: 10),
            TextField(controller: phoneCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Cep Telefonu (05XX...)', border: OutlineInputBorder())),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: type,
              decoration: const InputDecoration(labelText: 'Cari Türü', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'musteri', child: Text('Müşteri')),
                DropdownMenuItem(value: 'tedarikci', child: Text('Tedarikçi')),
              ],
              onChanged: (v) => type = v ?? 'musteri',
            ),
            const SizedBox(height: 14),
            FilledButton(
              onPressed: () async {
                final res = await ApiService.createCustomer(
                  name: nameCtrl.text.trim(),
                  type: type,
                  phone: phoneCtrl.text.trim(),
                );
                if (!mounted) return;
                Navigator.pop(ctx);
                if (res['ok'] == true) {
                  _loadAll();
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text((res['error'] as String?) ?? 'Hata')),
                  );
                }
              },
              child: const Text('Cariyi Kaydet'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final titles = ['Genel Bakış', 'Cari Hesaplar', 'Vade Takip'];
    return Scaffold(
      appBar: AppBar(
        title: Text(titles[_tab]),
        actions: [
          IconButton(
            tooltip: _hideAmounts ? 'Tutarları Göster' : 'Tutarları Gizle',
            icon: Icon(_hideAmounts ? Icons.visibility : Icons.visibility_off),
            onPressed: () => setState(() => _hideAmounts = !_hideAmounts),
          ),
          IconButton(
            tooltip: 'Çıkış Yap',
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await ApiService.logout();
              if (!mounted) return;
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const LoginScreen()),
              );
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openAddCustomerDialog,
        icon: const Icon(Icons.person_add),
        label: const Text('Yeni Cari'),
      ),
      body: RefreshIndicator(
        onRefresh: _loadAll,
        child: _tab == 0
            ? _buildDashboard()
            : (_tab == 1 ? _buildCustomers() : _buildDueTracking()),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Genel Bakış'),
          NavigationDestination(icon: Icon(Icons.people_outline), label: 'Cariler'),
          NavigationDestination(icon: Icon(Icons.calendar_today_outlined), label: 'Vade Takip'),
        ],
      ),
    );
  }

  Widget _buildDashboard() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _kpiCard('Toplam Alacak', _money(_dash['total_receivable'] ?? 0), Colors.red, Icons.payments_outlined),
        _kpiCard('Toplam Cari', '${_dash['total_customers'] ?? 0}', Colors.blue, Icons.people),
        _kpiCard('Geciken Toplam Kişi', '${_dash['overdue_count'] ?? 0}', Colors.orange, Icons.person_off_outlined),
        _kpiCard('Geciken Toplam Bakiye', _money(_dash['overdue_balance'] ?? 0), Colors.red.shade700, Icons.warning_amber_rounded),
      ],
    );
  }

  Widget _kpiCard(String title, String val, Color color, IconData icon) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: Color(0xFFE2E8F0))),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color.withOpacity(0.12), child: Icon(icon, color: color)),
        title: Text(title, style: const TextStyle(fontSize: 13, color: Colors.black54)),
        subtitle: Text(val, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
      ),
    );
  }

  Widget _buildCustomers() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            decoration: const InputDecoration(
              hintText: 'Cari adı veya telefon ara...',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(),
              isDense: true,
            ),
            onChanged: (v) {
              _search = v;
              _loadAll();
            },
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: _customers.length,
            itemBuilder: (_, i) {
              final c = _customers[i] as Map<String, dynamic>;
              final isNormal = (c['is_trusted'] ?? 1) == 1;
              return ListTile(
                leading: CircleAvatar(child: Text((c['account_name'] as String).substring(0, 1))),
                title: Text(c['account_name'] as String, style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text('${c['phone']} • ${isNormal ? 'Normal' : 'Geciken'}'),
                trailing: Text(_money(c['balance']), style: const TextStyle(fontWeight: FontWeight.bold)),
                onTap: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: c['id'] as int)),
                  );
                  _loadAll();
                },
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildDueTracking() {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _dueItems.length,
      itemBuilder: (_, i) {
        final item = _dueItems[i] as Map<String, dynamic>;
        final dueInfo = item['due_info'] as Map<String, dynamic>?;
        return Card(
          elevation: 0,
          margin: const EdgeInsets.only(bottom: 10),
          child: ListTile(
            title: Text(item['account_name'] as String, style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: Text('${item['due_date']} • ${dueInfo?['text'] ?? ''}'),
            trailing: Text(_money(item['amount']), style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.red)),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: item['customer_id'] as int)),
            ),
          ),
        );
      },
    );
  }
}
