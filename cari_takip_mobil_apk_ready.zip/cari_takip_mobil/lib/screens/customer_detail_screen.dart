import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/api_service.dart';

class CustomerDetailScreen extends StatefulWidget {
  final int customerId;
  const CustomerDetailScreen({super.key, required this.customerId});

  @override
  State<CustomerDetailScreen> createState() => _CustomerDetailScreenState();
}

class _CustomerDetailScreenState extends State<CustomerDetailScreen> {
  Map<String, dynamic>? _customer;
  List<dynamic> _txns = [];
  String _waUrl = '';

  String _txnType = 'borc';
  final _amountCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  String _dueDate = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await ApiService.getCustomerDetail(widget.customerId);
    if (!mounted) return;
    setState(() {
      _customer = data['customer'] as Map<String, dynamic>?;
      _txns = (data['transactions'] as List<dynamic>?) ?? [];
      _waUrl = (data['whatsapp_url'] as String?) ?? '';
    });
  }

  Future<void> _submitTxn() async {
    final amt = double.tryParse(_amountCtrl.text.replaceAll(',', '.')) ?? 0;
    if (amt <= 0) return;

    await ApiService.addTransaction(
      customerId: widget.customerId,
      txnType: _txnType,
      amount: amt,
      dueDate: _txnType == 'tahsilat' ? '' : _dueDate,
      description: _descCtrl.text.trim(),
    );
    _amountCtrl.clear();
    _descCtrl.clear();
    setState(() => _dueDate = '');
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final c = _customer;
    if (c == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final isNormal = (c['is_trusted'] ?? 1) == 1;
    final isTahsilat = _txnType == 'tahsilat';

    return Scaffold(
      appBar: AppBar(
        title: Text(c['account_name'] as String),
        actions: [
          IconButton(
            tooltip: 'WhatsApp Hatırlat',
            icon: const Icon(Icons.chat, color: Colors.green),
            onPressed: () async {
              if (_waUrl.isNotEmpty) {
                await launchUrl(Uri.parse(_waUrl), mode: LaunchMode.externalApplication);
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(c['phone'] as String, style: const TextStyle(color: Colors.black54)),
                      const SizedBox(height: 6),
                      Text('${c['balance']} ₺', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.red)),
                    ],
                  ),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: isNormal ? Colors.green : Colors.red,
                    ),
                    onPressed: () async {
                      await ApiService.toggleTrust(widget.customerId);
                      _load();
                    },
                    icon: Icon(isNormal ? Icons.check_circle : Icons.error_outline),
                    label: Text(isNormal ? 'Normal' : 'Geciken'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            elevation: 0,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  DropdownButtonFormField<String>(
                    value: _txnType,
                    decoration: const InputDecoration(labelText: 'İşlem Türü', border: OutlineInputBorder(), isDense: true),
                    items: const [
                      DropdownMenuItem(value: 'borc', child: Text('Borç Ekle (+)')),
                      DropdownMenuItem(value: 'tahsilat', child: Text('Tahsilat Al (-)')),
                    ],
                    onChanged: (v) => setState(() {
                      _txnType = v ?? 'borc';
                      if (_txnType == 'tahsilat') _dueDate = '';
                    }),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _amountCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Tutar (₺)', border: OutlineInputBorder(), isDense: true),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: isTahsilat
                        ? null
                        : () async {
                            final picked = await showDatePicker(
                              context: context,
                              firstDate: DateTime(2024),
                              lastDate: DateTime(2032),
                              initialDate: DateTime.now().add(const Duration(days: 7)),
                            );
                            if (picked != null) {
                              setState(() => _dueDate = picked.toIso8601String().substring(0, 10));
                            }
                          },
                    icon: const Icon(Icons.date_range),
                    label: Text(isTahsilat ? 'Vade (Tahsilatta Pasif)' : (_dueDate.isEmpty ? 'Vade Tarihi Seç (Opsiyonel)' : 'Vade: $_dueDate')),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _descCtrl,
                    decoration: const InputDecoration(labelText: 'Açıklama', border: OutlineInputBorder(), isDense: true),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: isTahsilat ? Colors.red : Colors.green,
                    ),
                    onPressed: _submitTxn,
                    icon: Icon(isTahsilat ? Icons.payments : Icons.add_circle),
                    label: Text(isTahsilat ? 'Tahsilat Yap' : 'Borç Ekle'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Cari Hesap Ekstresi', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          ..._txns.map((t) {
            final isDebt = t['txn_type'] == 'borc';
            return Card(
              elevation: 0,
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                title: Text((t['description'] as String?) ?? (isDebt ? 'Borç' : 'Tahsilat')),
                subtitle: Text('${t['created_at']} • ${t['days_ago'] ?? ''}'),
                trailing: Text(
                  '${isDebt ? '+' : '-'}${t['amount']} ₺',
                  style: TextStyle(fontWeight: FontWeight.bold, color: isDebt ? Colors.red : Colors.green),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
