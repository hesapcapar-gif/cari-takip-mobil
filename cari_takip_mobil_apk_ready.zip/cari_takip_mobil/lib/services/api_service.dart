import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class ApiService {
  // Canli sunucu veya yerel test adresinizi buraya yazin (ornegin: https://alanadiniz.com/cari_takip/api)
  static const String baseUrl = 'https://nabicapar.com/api';
  static const _storage = FlutterSecureStorage();
  static const _tokenKey = 'jwt_token';

  static Future<String?> getToken() => _storage.read(key: _tokenKey);

  static Future<void> saveToken(String token) =>
      _storage.write(key: _tokenKey, value: token);

  static Future<void> logout() => _storage.delete(key: _tokenKey);

  static Future<Map<String, String>> _headers() async {
    final token = await getToken();
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  static Future<Map<String, dynamic>> login(String email, String password) async {
    final res = await http.post(
      Uri.parse('$baseUrl/login.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode == 200 && data['ok'] == true) {
      await saveToken(data['token'] as String);
    }
    return data;
  }

  static Future<Map<String, dynamic>> getDashboard() async {
    final res = await http.get(
      Uri.parse('$baseUrl/dashboard.php'),
      headers: await _headers(),
    );
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  static Future<List<dynamic>> getCustomers([String query = '']) async {
    final uri = Uri.parse('$baseUrl/customers.php')
        .replace(queryParameters: query.isNotEmpty ? {'q': query} : null);
    final res = await http.get(uri, headers: await _headers());
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    return (data['customers'] as List<dynamic>?) ?? [];
  }

  static Future<Map<String, dynamic>> createCustomer({
    required String name,
    required String type,
    required String phone,
    String email = '',
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/customers.php'),
      headers: await _headers(),
      body: jsonEncode({
        'account_name': name,
        'account_type': type,
        'phone': phone,
        'email': email,
      }),
    );
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> getCustomerDetail(int id) async {
    final res = await http.get(
      Uri.parse('$baseUrl/customer_detail.php?id=$id'),
      headers: await _headers(),
    );
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> addTransaction({
    required int customerId,
    required String txnType,
    required double amount,
    String dueDate = '',
    String description = '',
  }) async {
    final res = await http.post(
      Uri.parse('$baseUrl/customer_detail.php?id=$customerId'),
      headers: await _headers(),
      body: jsonEncode({
        'action': 'add_txn',
        'txn_type': txnType,
        'amount': amount,
        'due_date': dueDate,
        'description': description,
      }),
    );
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  static Future<void> toggleTrust(int customerId) async {
    await http.post(
      Uri.parse('$baseUrl/customer_detail.php?id=$customerId'),
      headers: await _headers(),
      body: jsonEncode({'action': 'toggle_trust'}),
    );
  }

  static Future<List<dynamic>> getDueTracking() async {
    final res = await http.get(
      Uri.parse('$baseUrl/due_tracking.php'),
      headers: await _headers(),
    );
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    return (data['items'] as List<dynamic>?) ?? [];
  }
}
